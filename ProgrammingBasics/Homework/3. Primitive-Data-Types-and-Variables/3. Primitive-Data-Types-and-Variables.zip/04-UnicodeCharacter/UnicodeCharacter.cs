﻿using System;

class UnicodeCharacter
{
    static void Main(string[] args)
    {
        char symbol = '\u002A';
        Console.WriteLine(symbol);
    }
}

