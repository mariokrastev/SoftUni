﻿using System;

class FloatOrDouble
{
    static void Main(string[] args)
    {
        double firstValue = 34.567839023;
        float secondValue = 12.345f;
        double thirdValue = 8923.1234857;
        float fourthValue = 3456.091f;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}", firstValue, secondValue, thirdValue, fourthValue);
    }
}

