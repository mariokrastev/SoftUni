﻿using System;

class EmployeeData
{
    static void Main(string[] args)
    {

        string firstName = "Peter";
        string lastName = "Petrov";
        int age = 26;
        char gender = 'm';
        long IDNumber = 8910036386;
        int uniqueNumber = 27562758;
        Console.WriteLine("First Name: " + firstName);
        Console.WriteLine("Last Name: " + lastName);
        Console.WriteLine("Age: " + age);
        Console.WriteLine("Gender: " + gender);
        Console.WriteLine("Personal ID Number: " + IDNumber);
        Console.WriteLine("Unique Employee Number: " + uniqueNumber);





    }
}

