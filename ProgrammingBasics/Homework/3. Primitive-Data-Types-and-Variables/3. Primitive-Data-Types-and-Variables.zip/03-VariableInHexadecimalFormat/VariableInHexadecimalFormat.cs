﻿using System;

class VariableInHexadecimalFormat
{
    static void Main(string[] args)
    {
        int value = 0xFE;
        Console.WriteLine(value);
    }
}

